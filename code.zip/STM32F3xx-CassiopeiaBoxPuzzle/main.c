/*
    ChibiOS - Copyright (C) 2006..2018 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
 */


#include "ch.h"
#include "hal.h"

#include "chprintf.h"
#include "lsm303dlhc.h"
#include "l3gd20.h"

#define cls(chp)  chprintf(chp, "\033[2J\033[1;1H")

/*===========================================================================*/
/* LSM303DLHC related.                                                       */
/*===========================================================================*/

/* LSM303DLHC Driver: This object represent an LSM303DLHC instance */
static LSM303DLHCDriver LSM303DLHCD1;

//static int32_t accraw[LSM303DLHC_ACC_NUMBER_OF_AXES];
//static int32_t compraw[LSM303DLHC_COMP_NUMBER_OF_AXES];

static float acccooked[LSM303DLHC_ACC_NUMBER_OF_AXES];
//static float compcooked[LSM303DLHC_COMP_NUMBER_OF_AXES];

static char axisID[LSM303DLHC_ACC_NUMBER_OF_AXES] = {'X', 'Y', 'Z'};
static uint32_t i;

static const I2CConfig i2ccfg = {
                                 STM32_TIMINGR_PRESC(15U) |
                                 STM32_TIMINGR_SCLDEL(4U) | STM32_TIMINGR_SDADEL(2U) |
                                 STM32_TIMINGR_SCLH(15U)  | STM32_TIMINGR_SCLL(21U),
                                 0,
                                 0
};

static const LSM303DLHCConfig lsm303dlhccfg = {
                                               &I2CD1,
                                               &i2ccfg,
                                               NULL,
                                               NULL,
                                               LSM303DLHC_ACC_FS_4G,
                                               LSM303DLHC_ACC_ODR_100Hz,
#if LSM303DLHC_USE_ADVANCED
                                               LSM303DLHC_ACC_LP_DISABLED,
                                               LSM303DLHC_ACC_HR_DISABLED,
                                               LSM303DLHC_ACC_BDU_BLOCK,
                                               LSM303DLHC_ACC_END_LITTLE,
#endif
                                               NULL,
                                               NULL,
                                               LSM303DLHC_COMP_FS_1P3GA,
                                               LSM303DLHC_COMP_ODR_30HZ,
#if LSM303DLHC_USE_ADVANCED
                                               LSM303DLHC_COMP_MD_BLOCK
#endif
};

/*===========================================================================*/
/* L3GD20 related.                                                           */
/*===========================================================================*/

/* L3GD20 Driver: This object represent an L3GD20 instance.*/
static L3GD20Driver L3GD20D1;

static int32_t gyroraw[L3GD20_GYRO_NUMBER_OF_AXES];
static float gyrocooked[L3GD20_GYRO_NUMBER_OF_AXES];

/*
 * static char axisID[L3GD20_GYRO_NUMBER_OF_AXES] = {'X', 'Y', 'Z'};
 * static uint32_t i;
 */

static const SPIConfig spicfg = {
                                 FALSE,
                                 NULL,
                                 GPIOE,
                                 GPIOE_L3GD20_CS,
                                 SPI_CR1_BR | SPI_CR1_CPOL | SPI_CR1_CPHA,
                                 0
};

static L3GD20Config l3gd20cfg = {
                                 &SPID1,
                                 &spicfg,
                                 NULL,
                                 NULL,
                                 L3GD20_FS_250DPS,
                                 L3GD20_ODR_760HZ,
#if L3GD20_USE_ADVANCED
                                 L3GD20_BDU_CONTINUOUS,
                                 L3GD20_END_LITTLE,
                                 L3GD20_BW3,
                                 L3GD20_HPM_REFERENCE,
                                 L3GD20_HPCF_8,
                                 L3GD20_LP2M_ON,
#endif
};

/*===========================================================================*/
/* Puzzle code.                                                              */
/*===========================================================================*/

// The stars are named with Greek letters from alfa to epsilon
#define alfa                        PAL_LINE(GPIOC, 0U) /* Alfa Cassiopeiae */
#define beta                        PAL_LINE(GPIOC, 1U) /* Beta Cassiopeiae */
#define gamma                       PAL_LINE(GPIOC, 2U) /* Gamma Cassiopeiae */
#define delta                       PAL_LINE(GPIOC, 3U) /* Delta Cassiopeiae */
#define epsilon                     PAL_LINE(GPIOB, 0U) /* Epsilon Cassiopeiae */
// Here there are 3 extra stars not related to the constellation
#define extra_1                     PAL_LINE(GPIOB, 1U)
#define extra_2                     PAL_LINE(GPIOB, 2U)
#define extra_3                     PAL_LINE(GPIOE, 7U)

#define PROGRAM_DELAY                  200

static float accelerometer_x_axis;
static float accelerometer_y_axis;
static float accelerometer_z_axis;

static float gyroscope_x_axis;
static float gyroscope_y_axis;
static float gyroscope_z_axis;

static const float accelerometer_x_axis_solution = 625.0;
static const float accelerometer_y_axis_solution = 210.0;
static const float accelerometer_z_axis_solution = 720.0;

static const float gyroscope_x_axis_solution = 0.0;
static const float gyroscope_y_axis_solution = 0.0;
static const float gyroscope_z_axis_solution = 0.0;


/*
 * Useful function
 *
 * */

static bool is_around(float variable, float value, float range) {
  if(variable > value-range && variable < value+range)
    return true;
  return false;
}

/*
 * Debug sequence
 *
 * */

static void show_debug_sequence(void) {

  int index;

  // Turn off everything
  palClearLine(alfa);
  palClearLine(beta);
  palClearLine(gamma);
  palClearLine(delta);
  palClearLine(epsilon);
  palClearLine(extra_1);
  palClearLine(extra_2);
  palClearLine(extra_3);

  // Do light game
  for(index = 0; index < 4; index++) {
    palToggleLine(alfa);
    chThdSleepMilliseconds(50);
    palToggleLine(beta);
    chThdSleepMilliseconds(50);
    palToggleLine(gamma);
    chThdSleepMilliseconds(50);
    palToggleLine(delta);
    chThdSleepMilliseconds(50);
    palToggleLine(epsilon);
    chThdSleepMilliseconds(50);
    palToggleLine(extra_1);
    chThdSleepMilliseconds(50);
    palToggleLine(extra_2);
    chThdSleepMilliseconds(50);
    palToggleLine(extra_3);
    chThdSleepMilliseconds(50);
  }

  // Turn on everything
  palSetLine(alfa);
  palSetLine(beta);
  palSetLine(gamma);
  palSetLine(delta);
  palSetLine(epsilon);
  palSetLine(extra_1);
  palSetLine(extra_2);
  palSetLine(extra_3);
  chThdSleepMilliseconds(1500);

  // Turn off the incorrect ones
  palClearLine(extra_1);
  palClearLine(extra_2);
  palClearLine(extra_3);
  chThdSleepMilliseconds(1500);

  // Turn off everything
  palClearLine(alfa);
  palClearLine(beta);
  palClearLine(gamma);
  palClearLine(delta);
  palClearLine(epsilon);


}


/*
 * Winning sequence
 *
 * */

static void show_winning_sequence(void){

  int index;

  // Turn off everything
  palClearLine(alfa);
  palClearLine(beta);
  palClearLine(gamma);
  palClearLine(delta);
  palClearLine(epsilon);
  palClearLine(extra_1);
  palClearLine(extra_2);
  palClearLine(extra_3);

  // Do light game
  for(index = 0; index < 2; index++) {
    palToggleLine(alfa);
    chThdSleepMilliseconds(75);
    palToggleLine(beta);
    chThdSleepMilliseconds(75);
    palToggleLine(gamma);
    chThdSleepMilliseconds(75);
    palToggleLine(delta);
    chThdSleepMilliseconds(75);
    palToggleLine(epsilon);
    chThdSleepMilliseconds(75);
    palToggleLine(extra_1);
    chThdSleepMilliseconds(75);
    palToggleLine(extra_2);
    chThdSleepMilliseconds(75);
    palToggleLine(extra_3);
    chThdSleepMilliseconds(75);
  }

  // Be sure the incorrect ones are off
  palClearLine(extra_1);
  palClearLine(extra_2);
  palClearLine(extra_3);

  // Turn on only the correct ones
  palSetLine(alfa);
  chThdSleepMilliseconds(100);
  palSetLine(beta);
  chThdSleepMilliseconds(100);
  palSetLine(gamma);
  chThdSleepMilliseconds(100);
  palSetLine(delta);
  chThdSleepMilliseconds(100);
  palSetLine(epsilon);

  // Stop for a while
  chThdSleepMilliseconds(5000);

  // Blink before resetting
  for(index = 0; index < 6; index++) {
    palToggleLine(alfa);
    palToggleLine(beta);
    palToggleLine(gamma);
    palToggleLine(delta);
    palToggleLine(epsilon);
    chThdSleepMilliseconds(1000);
  }

}

/*
 * Single stars puzzle logic
 *
 * The only constraint is that at the correct accelerometer and gyroscope coordinates
 * the "star LEDs" must be turned on and the "extra star LEDs" must be turned off
 *
 * */

static bool is_alfa_shining(void) {
  if (is_around(accelerometer_x_axis, accelerometer_x_axis_solution, 600) &&
      is_around(accelerometer_y_axis, accelerometer_y_axis_solution, 600) &&
      is_around(accelerometer_z_axis, accelerometer_z_axis_solution, 600)) {
    return true;
  }
  return false;
}

static bool is_beta_shining(void) {
  if (is_around(accelerometer_x_axis, accelerometer_x_axis_solution, 500) &&
      is_around(accelerometer_y_axis, accelerometer_y_axis_solution, 500) &&
      is_around(accelerometer_z_axis, accelerometer_z_axis_solution, 500)) {
    return true;
  }
  return false;
}

static bool is_gamma_shining(void) {
  if (is_around(accelerometer_x_axis, accelerometer_x_axis_solution, 400.0) &&
      is_around(accelerometer_y_axis, accelerometer_y_axis_solution, 400.0) &&
      is_around(accelerometer_z_axis, accelerometer_z_axis_solution, 400.0)) {
    return true;
  }
  return false;
}

static bool is_delta_shining(void) {
  if (is_around(accelerometer_x_axis, accelerometer_x_axis_solution, 700) &&
      is_around(accelerometer_y_axis, accelerometer_y_axis_solution, 700) &&
      is_around(accelerometer_z_axis, accelerometer_z_axis_solution, 700)) {
    return true;
  }
  return false;
}

static bool is_epsilon_shining(void) {
  if (is_around(gyroscope_x_axis, gyroscope_x_axis_solution, 50.0) &&
      is_around(gyroscope_y_axis, gyroscope_y_axis_solution, 50.0) &&
      is_around(gyroscope_z_axis, gyroscope_z_axis_solution, 50.0)) {
    return true;
  }
  return false;
}

static bool is_extra_1_shining(void) {
  if (accelerometer_x_axis < -500.0 &&
      accelerometer_y_axis < -500.0 &&
      accelerometer_z_axis < -500.0) {
    return true;
  }
  return false;
}

static bool is_extra_2_shining(void) {
  if (accelerometer_x_axis < 0.0 ||
      accelerometer_y_axis < 0.0 ||
      accelerometer_z_axis < 0.0) {
    return true;
  }
  return false;
}

static bool is_extra_3_shining(void) {
  if (!is_around(gyroscope_x_axis, gyroscope_x_axis_solution, 50.0) ||
      !is_around(gyroscope_y_axis, gyroscope_y_axis_solution, 50.0) ||
      !is_around(gyroscope_z_axis, gyroscope_z_axis_solution, 50.0)) {
    return true;
  }
  else if(!is_around(accelerometer_x_axis, accelerometer_x_axis_solution, 450.0) ||
      !is_around(accelerometer_y_axis, accelerometer_y_axis_solution, 450.0) ||
      !is_around(accelerometer_z_axis, accelerometer_z_axis_solution, 450.0)) {
    return true;
  }
  return false;
}

static THD_WORKING_AREA(waConstellationThread, 128);
static THD_FUNCTION(ConstellationThread, arg) {

  bool alfa_shines, beta_shines, gamma_shines, delta_shines, epsilon_shines;
  bool extra_1_shines, extra_2_shines, extra_3_shines;

  (void)arg;
  chRegSetThreadName("Constellation Thread");

  palSetLineMode(alfa,    PAL_MODE_OUTPUT_PUSHPULL);
  palSetLineMode(beta,    PAL_MODE_OUTPUT_PUSHPULL);
  palSetLineMode(gamma,   PAL_MODE_OUTPUT_PUSHPULL);
  palSetLineMode(delta,   PAL_MODE_OUTPUT_PUSHPULL);
  palSetLineMode(epsilon, PAL_MODE_OUTPUT_PUSHPULL);
  palSetLineMode(extra_1, PAL_MODE_OUTPUT_PUSHPULL);
  palSetLineMode(extra_2, PAL_MODE_OUTPUT_PUSHPULL);
  palSetLineMode(extra_3, PAL_MODE_OUTPUT_PUSHPULL);

  // Startup debug sequence
  show_debug_sequence();

  while(true) {

    /*Check for the state of the stars*/
    alfa_shines =    is_alfa_shining();
    beta_shines =    is_beta_shining();
    gamma_shines =   is_gamma_shining();
    delta_shines =   is_delta_shining();
    epsilon_shines = is_epsilon_shining();
    extra_1_shines = is_extra_1_shining();
    extra_2_shines = is_extra_2_shining();
    extra_3_shines = is_extra_3_shining();

    /*Turn on/off the starts accordingly to their activation function*/
    alfa_shines    ? palSetLine(alfa)    : palClearLine(alfa);
    beta_shines    ? palSetLine(beta)    : palClearLine(beta);
    gamma_shines   ? palSetLine(gamma)   : palClearLine(gamma);
    delta_shines   ? palSetLine(delta)   : palClearLine(delta);
    epsilon_shines ? palSetLine(epsilon) : palClearLine(epsilon);
    extra_1_shines ? palSetLine(extra_1) : palClearLine(extra_1);
    extra_2_shines ? palSetLine(extra_2) : palClearLine(extra_2);
    extra_3_shines ? palSetLine(extra_3) : palClearLine(extra_3);

    /*Check if the sequence is winning*/
    if (alfa_shines     &&
        beta_shines     &&
        gamma_shines    &&
        delta_shines    &&
        epsilon_shines  &&
        !extra_1_shines &&
        !extra_2_shines &&
        !extra_3_shines) {
      show_winning_sequence();
    }

    chThdSleepMilliseconds(PROGRAM_DELAY);
  }
}

/*===========================================================================*/
/* Application entry point.                                                  */
/*===========================================================================*/

static BaseSequentialStream* chp = (BaseSequentialStream*)&SD1;

int main(void) {

  halInit();
  chSysInit();

  sdStart(&SD1, NULL);

  /* Creates the Constellation Thread managing the logic of the puzzle */
  chThdCreateStatic(waConstellationThread, sizeof(waConstellationThread), NORMALPRIO-1, ConstellationThread, NULL);


  lsm303dlhcObjectInit(&LSM303DLHCD1);            /* LSM303DLHC Object Initialization.*/
  lsm303dlhcStart(&LSM303DLHCD1, &lsm303dlhccfg); /* Activates the LSM303DLHC driver.*/

  l3gd20ObjectInit(&L3GD20D1);                    /* L3GD20 Object Initialization.*/
  l3gd20Start(&L3GD20D1, &l3gd20cfg);             /* Activates the L3GD20 driver.*/

  while (true) {

    /*SERIAL PRINT*/
    lsm303dlhcAccelerometerReadCooked(&LSM303DLHCD1, acccooked);
    chprintf(chp, "LSM303DLHC Accelerometer cooked data...\r\n");
    for(i = 0; i < LSM303DLHC_ACC_NUMBER_OF_AXES; i++) {
      chprintf(chp, "%c-axis: %.3f\r\n", axisID[i], acccooked[i]);
    }

    l3gd20GyroscopeReadRaw(&L3GD20D1, gyroraw);
    chprintf(chp, "L3GD20 Gyroscope raw data...\r\n");
    for(i = 0; i < L3GD20_GYRO_NUMBER_OF_AXES; i++) {
      chprintf(chp, "%c-axis: %d\r\n", axisID[i], gyroraw[i]);
    }

    l3gd20GyroscopeReadCooked(&L3GD20D1, gyrocooked);
    chprintf(chp, "L3GD20 Gyroscope cooked data...\r\n");
    for(i = 0; i < L3GD20_GYRO_NUMBER_OF_AXES; i++) {
      chprintf(chp, "%c-axis: %.3f\r\n", axisID[i], gyrocooked[i]);
    }

    /*SAVE DATA*/
    accelerometer_x_axis = acccooked[0];
    accelerometer_y_axis = acccooked[1];
    accelerometer_z_axis = acccooked[2];

    gyroscope_x_axis = gyrocooked[0];
    gyroscope_y_axis = gyrocooked[1];
    gyroscope_z_axis = gyrocooked[2];

    chThdSleepMilliseconds(PROGRAM_DELAY);
    cls(chp);
  }

  /* STOP */
  lsm303dlhcStop(&LSM303DLHCD1);
  l3gd20Stop(&L3GD20D1);
}
